const hideSidebar = ()=>{
    const sideBar = document.querySelector('.sidebar')
    sideBar.style.display = 'none'
}

const showSidebar = ()=>{
    const sideBar = document.querySelector('.sidebar')
    sideBar.style.display = 'block'
}

const hideSidebar2 = ()=>{
    const sideBar2 = document.querySelector('.sidebar2')
    sideBar2.style.display = 'none'
}

const showSidebar2 = ()=>{
    const sideBar2 = document.querySelector('.sidebar2')
    sideBar2.style.display = 'block'
}